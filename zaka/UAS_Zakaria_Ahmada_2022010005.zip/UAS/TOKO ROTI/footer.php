 	<!-- Google Web Fonts -->
	 <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Oswald:wght@500;600;700&family=Pacifico&display=swap" rel="stylesheet"> 

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<footer style="background-image: url(image/home/footer_pattern.png); box-sizing: border; ">
		<div class="container">
            <div class="row gx-5">
                <div class="col-lg-4 col-md-6 mb-lg-n5">
                    <div class="d-flex flex-column align-items-center justify-content-center text-center h-100 ">
					<h3 style="color:orange"><b>MAPS</b></h3> <br>
					<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3963.0087262569255!2d110.72580017453694!3d-6.645836864967028!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e70df9b775d50c7%3A0xc447666126edf104!2sCatering%20AHZA!5e0!3m2!1sid!2sid!4v1705800582828!5m2!1sid!2sid" width="350px" height="280px" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>
                </div>
                <div class="col-lg-8 col-md-6" style="color : white; padding-left:60px">
                    <div class="row gx-5">
                        <div class="col-lg-4 col-md-12 pt-5 mb-5"><br>
                            <h4 class="text-primary text-uppercase mb-4" style="color: orange;"><b>Kontak</b></h4>
                            <div class="d-flex mb-2">
                                <i class="bi bi-geo-alt text-primary me-2"></i>
                                <p class="mb-0">Ngasem, Batealit, Jepara, Jawa Tengah, Indonesia</p>
                            </div>
                            <div class="d-flex mb-2">
                                <i class="bi bi-envelope-open text-primary me-2"></i>
                                <p class="mb-0">ahzacakeandbakery.com</p>
                            </div>
                            <div class="d-flex mb-2">
                                <i class="bi bi-telephone text-primary me-2"></i>
                                <p class="mb-0">+62 838-2673-5849</p>
                            </div>
                            <div class="d-flex mt-4">
                                <a class="btn btn-lg btn-primary btn-lg-square border-inner rounded-0 me-2" href="#"><i class="fab fa-twitter fw-normal"></i></a>
                                <a class="btn btn-lg btn-primary btn-lg-square border-inner rounded-0 me-2" href="#"><i class="fab fa-facebook-f fw-normal"></i></a>
                                <a class="btn btn-lg btn-primary btn-lg-square border-inner rounded-0 me-2" href="#"><i class="fab fa-linkedin-in fw-normal"></i></a>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-12 pt-0 pt-lg-5 mb-5"><br>
                            <h4 class="text-primary text-uppercase mb-4" style="color: orange;"><b>Tautan Langsung</b></h4>
                            <div class="d-flex flex-column justify-content-start">
                                <a class="text-secondary mb-2" href="index.php" style="color:white;"><i class="bi bi-arrow-right text-primary me-2"></i> Home</a><br>
                                <a class="text-secondary mb-2" href="produk.php" style="color:white;"><i class="bi bi-arrow-right text-primary me-2"></i> Produk</a><br>
                                <a class="text-secondary mb-2" href="about.php" style="color:white;"><i class="bi bi-arrow-right text-primary me-2"></i> Tentang kami</a><br>
                                <a class="text-secondary mb-2" href="keranjang.php" style="color:white;"><i class="bi bi-arrow-right text-primary me-2"></i> Keranjang</a><br>
                                <a class="text-secondary mb-2" href="user_login.php" style="color:white;"><i class="bi bi-arrow-right text-primary me-2"></i> Login</a><br>
                                <a class="text-secondary" href="register.php" style="color:white;"><i class="bi bi-arrow-right text-primary me-2"></i> Registrasi</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<div class="container-fluid bg-img text-secondary" style="margin-top: 90px">
        
    </div>
    <div class="container-fluid text-secondary py-4" style="background: #111111;">
        <div class="container text-center">
        <h5 class="text-center">Copyright&copy; Zakaria Ahmada</h5>
        </div>
    </div>
		<!--<div class="container" style="padding-bottom: 50px;">
			<div class="row">
				<div class="col-md-4" style="background-color: #F4E2C7; ">
					<h3 style="color: rgb(102, 55, 55);"><b>AHZA-CAKE BAKERY</b></h3>
					<p>Ds. Ngasem Kec. Batealit Kab. Jepara</p>
					<p><i class="glyphicon glyphicon-earphone"></i> +6287804616097</p>
					<p><i class="glyphicon glyphicon-envelope"></i> ahzacakeandbakery@gmail.com</p>
				</div>
				<div class="col-md-4" style="background-color: #F4E2C7; ">
					<h5><b>Menu</b></h5>
					<p><a href=""  style="color: #000">Produk</a></p>
					<p><a href=""  style="color: #000">Tentang kami</a></p>
					<p style="margin-bottom: 30px;"><a href=""  style="color: #000;">Hubungi Kami</a></p>
				</div>

				<div class="col-md-4">
					
				</div>
			</div>

		</div>

		<div class="copy" style="background-color: #DBAD90; padding: 5px; color: #fff; text-align: center;">
			<span>Copyright&copy; Zakaria Ahmada</span>
		</div>
	</footer>

</body>
</html> -->
<!-- Footer Start -->
    <!-- Footer End -->