<?php 
	include 'header.php';
 ?>
 <!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
  </head>
  <body style="">
<!-- <div class="container" style="padding-bottom: 300px;">
	<h2 style=" width: 100%; border-bottom: 4px solid #ff8680"><b>Tentang Kami</b></h2>
	<p class="text-justify">Rapi Cake & Bakery adalah rantai toko roti Indonesia terkemuka dengan 22 cabang (dapur pusat) yang mengelola lebih dari 400 outlet: Jabodetabek (Gajah Mada, Pondok Pinang, Jatinegara, Cikini, Sunter, Serpong, Ciputat, Pekayon, Bogor dan Karawang), Bandung, Surabaya, Lampung, Batam, Pekanbaru, Makassar, Manado, Bali, Solo, Semarang, Balikpapan, dan Samarinda. Kami masih terus memperluas secara nasional ke kota-kota lain.</p>
<p>
Rapi Cake & Bakery  adalah salah satu pelopor pertama dalam bisnis roti modern di Indonesia. Didirikan pada tahun 1978, saat ini dikelola di bawah PT. Mustika Citra Rasa. Produk kami sehat, bergizi, dan terjangkau oleh semua orang.</p>
</div> -->
<div class="container-fluid pt-5">
        <div class="container">
            <div class="section-title position-relative text-center mx-auto mb-5 pb-3" style="max-width: 600px text-align:center;">
                <!-- <h2 class="text-warning font-secondary">TENTANG KAMI</h2> -->
                <h1 class="display-4 text-uppercase" style=" width: 100%;">Selamat Datang Di AHZA CAKE</h1>
            </div>
            <div class="row gx-5">
                <div class="col-lg-5 mb-5 mb-lg-0" style="min-height: 400px;">
                    <div class="position-relative h-100">
                        <img class="position-absolute w-100 h-100" src="image/produk/tentang.jpg" style="object-fit: cover; width: 100%;">
                    </div>
                </div>
                <div class="col-lg-6 pb-5">
                    <h4 class="mb-4">Ahza Cake & Bakery sudah berdiri sejak 12 tahun lalu, berawal dari usaha rumahan kecil-kecilan sekarang sudah ada 6 toko yang berada di Jepara dan Kudus. Kami merupakan produsen cake yang halal dengan bahan berkualitas dan terjangkau untuk semua kalangan. Produk kami terdiri dari berbagai macam cake tart, produk oleh-oleh, roti gurih dan kue kering. </h4>
                    <p class="mb-5"></p>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
 <?php 
	include 'footer.php';
 ?>