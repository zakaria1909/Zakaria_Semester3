<?php 
	include 'header.php';
 ?>
<body style="">
<div class="container" style="padding-bottom: 250px;">
		<h2 style=" width: 100%; text-align:center;"><b>Login</b></h2><br>

<form action="proses/login.php" method="POST">
		<div class="form-group">
			<label for="exampleInputEmail1">username</label>
			<input type="text" class="form-control" id="exampleInputEmail1" placeholder="Username" name="username" style="width: 500px;">
		</div>
		
		<div class="form-group">
			<label for="exampleInputEmail1">Password</label>
			<input type="password" class="form-control" id="exampleInputEmail1" placeholder="Password" name="pass" style="width: 500px;">
		</div>
		<button type="submit" class="btn btn-success"><i class="bi bi-person-fill"></i> Login</button>
		<a href="register.php" class="btn btn-primary"><i class="bi bi-person-plus-fill"></i> Daftar</a>
	</form>
</div>

</body>
 <?php 
	include 'footer.php';
 ?>