<?php 
	include 'header.php';
 ?>
<body style="background-color:#F4E2C7 ;">
<div class="container" style="padding-bottom: 300px;">
	<h2 class="bg-success text-center" style="padding: 10px; background-color:#198754;">Checkout Berhasil</h2>
	<h4 class="text-center" style="font-weight: bold;">Terimakasih Sudah Berbelanja di Ahza-Cake Backery, Pesananmu sedang diproses silahkan tunggu barangmu dirumah ya.. :)</h4>
	
</div>
</body>


 <?php 
	include 'footer.php';
 ?>