<?php 
	include 'header.php';
 ?>
<!-- PRODUK TERBARU -->
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
  </head>
<body style="background-color:grey ;">
	

<div class="container">
	<h2 style=" width: 100%; text-align:center;"><b>Produk Kami</b></h2>

	
		<?php 
		$result = mysqli_query($conn, "SELECT * FROM produk");
		while ($row = mysqli_fetch_assoc($result)) {
			?>
			<div class="col-sm-6 col-md-3">
			<div class="thumbnail">
					<img src="image/produk/<?= $row['image']; ?>" >
					<div class="caption">
						<h3><b><?= $row['nama'];  ?></b></h3>
						<h4>Rp.<?= number_format($row['harga']); ?></h4>
						<div class="row">
							<div class="col-md-6">
								<a href="detail_produk.php?produk=<?= $row['kode_produk']; ?>" class="btn btn-warning btn-block" style="border-radius: 15px 15px 15px 15px;">Detail</a> 
							</div>
							<?php if(isset($_SESSION['kd_cs'])){ ?>
								<div class="col-md-6">
									<a href="proses/add.php?produk=<?= $row['kode_produk']; ?>&kd_cs=<?= $kode_cs; ?>&hal=1" class="btn btn-success btn-block" role="button" style="border-radius: 15px 15px 15px 15px;"><i class="glyphicon glyphicon-shopping-cart"></i></a>
								</div>
								<?php 
							}
							else{
								?>
								<div class="col-md-6">
									<a href="keranjang.php" class="btn btn-success btn-block" role="button" style="border-radius: 15px 15px 15px 15px;"><i class="glyphicon glyphicon-shopping-cart"></i></a>
								</div>

								<?php 
							}
							?>

						</div>

					</div>
				</div>
			</div>
			<?php 
		}
		?>
	

</div>
</body>
</html>
 <?php 
	include 'footer.php';
 ?>