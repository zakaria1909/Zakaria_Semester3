-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 24, 2024 at 06:26 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `roti`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'admin', '$2y$10$AIy0X1Ep6alaHDTofiChGeqq7k/d1Kc8vKQf1JZo0mKrzkkj6M626');

-- --------------------------------------------------------

--
-- Table structure for table `bom_produk`
--

CREATE TABLE `bom_produk` (
  `kode_bom` varchar(100) NOT NULL,
  `kode_bk` varchar(100) NOT NULL,
  `kode_produk` varchar(100) NOT NULL,
  `nama_produk` varchar(200) NOT NULL,
  `kebutuhan` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bom_produk`
--

INSERT INTO `bom_produk` (`kode_bom`, `kode_bk`, `kode_produk`, `nama_produk`, `kebutuhan`) VALUES
('B0001', 'M0006', 'P0001', 'Brownis', '0.5'),
('B0001', 'M0002', 'P0001', 'Brownis', '0.2'),
('B0001', 'M0001', 'P0001', 'Brownis', '0.5'),
('B0001', 'M0010', 'P0001', 'Brownis', '0.2'),
('B0001', 'M0011', 'P0001', 'Brownis', '0.5'),
('B0002', 'M0001', 'P0002', 'Caramel', '1'),
('B0001', 'M0015', 'P0001', 'Brownis', '1'),
('B0002', 'M0003', 'P0002', 'Caramel', '0.3'),
('B0002', 'M0002', 'P0002', 'Caramel', '0.2'),
('B0002', 'M0006', 'P0002', 'Caramel', '0.5'),
('B0002', 'M0011', 'P0002', 'Caramel', '0.5'),
('B0002', 'M0014', 'P0002', 'Caramel', '0.2'),
('B0002', 'M0019', 'P0002', 'Caramel', '0.2'),
('B0002', 'M0020', 'P0002', 'Caramel', '0.5'),
('B0003', 'M0001', 'P0003', 'Bolu Band', '0.8'),
('B0003', 'M0002', 'P0003', 'Bolu Band', '0.2'),
('B0003', 'M0003', 'P0003', 'Bolu Band', '2'),
('B0003', 'M0007', 'P0003', 'Bolu Band', '0.5'),
('B0003', 'M0010', 'P0003', 'Bolu Band', '0.3'),
('B0003', 'M0011', 'P0003', 'Bolu Band', '0.5'),
('B0003', 'M0014', 'P0003', 'Bolu Band', '0.5'),
('B0003', 'M0015', 'P0003', 'Bolu Band', '0.5'),
('B0004', 'M0001', 'P0004', 'Kue Mangkok 4', '0.5'),
('B0004', 'M0002', 'P0004', 'Kue Mangkok 4', '0.1'),
('B0004', 'M0003', 'P0004', 'Kue Mangkok 4', '1'),
('B0004', 'M0010', 'P0004', 'Kue Mangkok 4', '0.2'),
('B0004', 'M0011', 'P0004', 'Kue Mangkok 4', '0.5'),
('B0005', 'M0001', 'P0005', 'Donut 4', '0.8'),
('B0005', 'M0002', 'P0005', 'Donut 4', '0.2'),
('B0005', 'M0008', 'P0005', 'Donut 4', '0.5'),
('B0005', 'M0011', 'P0005', 'Donut 4', '0.5'),
('B0005', 'M0012', 'P0005', 'Donut 4', '1'),
('B0005', 'M0018', 'P0005', 'Donut 4', '1.4'),
('B0005', 'M0019', 'P0005', 'Donut 4', '0.5'),
('B0005', 'M0017', 'P0005', 'Donut 4', '1.5'),
('B0006', 'M0001', 'P0006', 'angel food cake', '1'),
('B0007', 'M0001', 'P0007', 'Bisquit Cake', '1');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `kode_customer` varchar(100) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `telp` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`kode_customer`, `nama`, `email`, `username`, `password`, `telp`) VALUES
('C0001', 'Zakaria Ahmada', 'zakariaahmada19@gmail.com', 'zaka', '$2y$10$3WF/OrFxbLctXfYVUlyUgus2bjgsWHNyog0MsXFH05gxDmIsj2/SO', '085225527528'),
('C0002', 'azizi', 'zakariaa19@gmail.com', 'azizi', '$2y$10$3JzsCRezDlwz4.JTWvvu1uLSIepTbPqsj9pflN1b3J.mn8P6AstPK', '085225528528'),
('C0003', 'zakaria', 'zakariaahmada19@gmail.com', 'zakaria', '$2y$10$qSc5pDc0eK9a0uSOtzS0KOOlfPkln8g9kzcTwSWlSGOvQQEHS.4ZK', '085225527528');

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `kode_bk` varchar(100) NOT NULL,
  `nama` varchar(200) NOT NULL,
  `qty` varchar(200) NOT NULL,
  `satuan` varchar(200) NOT NULL,
  `harga` int(11) NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`kode_bk`, `nama`, `qty`, `satuan`, `harga`, `tanggal`) VALUES
('M0001', 'Tepung Tapioka', '92.4', 'Kg', 13000, '2024-01-20'),
('M0002', 'Soda Kue Jepang', '3.2', 'Kg', 25000, '2024-01-20'),
('M0003', 'Panili', '494.5', 'gram', 3000, '2024-01-20'),
('M0004', 'Keju', '20', 'Kg', 40000, '2024-01-20'),
('M0005', 'Coklat manis', '30', 'Kg', 27000, '2024-01-20'),
('M0006', 'Tepung Cokro', '96.5', 'kg', 12000, '2024-01-20'),
('M0007', 'Tepung Payung', '99', 'kg', 10000, '2024-01-20'),
('M0008', 'Tepung Segitiga', '100', 'kg', 12000, '2024-01-20'),
('M0009', 'Farnipan', '10', 'kg', 80000, '2024-01-20'),
('M0010', 'Pelembut', '4', 'kg', 90000, '2024-01-20'),
('M0011', 'Telur', '495.5', 'kg', 25000, '2024-01-20'),
('M0012', 'Full Cream', '20', 'kg', 35000, '2024-01-20'),
('M0013', 'Ovalet SP', '5', 'kg', 30000, '2024-01-20'),
('M0014', 'Margarin', '48', 'kg', 30000, '2024-01-20'),
('M0015', 'Gula Pasir', '97', 'kg', 18000, '2024-01-20'),
('M0016', 'Susu Kantal Manis', '30', 'kg', 32000, '2024-01-20'),
('M0017', 'Meces/Ceres', '30', 'kg', 28000, '2024-01-20'),
('M0018', 'Butter Cream', '10', 'kg', 28000, '2024-01-20'),
('M0019', 'Minyak', '49', 'kg', 18000, '2024-01-20'),
('M0020', 'Gula Merah', '47.5', 'kg', 18000, '2024-01-20');

-- --------------------------------------------------------

--
-- Table structure for table `keranjang`
--

CREATE TABLE `keranjang` (
  `id_keranjang` int(11) NOT NULL,
  `kode_customer` varchar(100) NOT NULL,
  `kode_produk` varchar(100) NOT NULL,
  `nama_produk` varchar(100) NOT NULL,
  `qty` int(11) NOT NULL,
  `harga` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `keranjang`
--

INSERT INTO `keranjang` (`id_keranjang`, `kode_customer`, `kode_produk`, `nama_produk`, `qty`, `harga`) VALUES
(31, 'C0007', 'P0002', 'Caramel', 3, 35000);

-- --------------------------------------------------------

--
-- Table structure for table `produk`
--

CREATE TABLE `produk` (
  `kode_produk` varchar(100) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `image` text NOT NULL,
  `deskripsi` text NOT NULL,
  `harga` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `produk`
--

INSERT INTO `produk` (`kode_produk`, `nama`, `image`, `deskripsi`, `harga`) VALUES
('P0001', 'Brownis', '65ab48d8812a0.jpg', 'brownis enak	', 25000),
('P0002', 'Caramel', '65ab499ec3a75.jpeg', '				Caramel manis enak\r\n						', 35000),
('P0003', 'Bolu Band', '65ab4fbb69475.jpeg', 'Lembut\r\n			', 25000),
('P0004', 'Kue Mangkok 4', '65ab50c391f50.jpeg', 'Lembut Enak\r\n			', 10000),
('P0005', 'Donut 4', '65ab51bf917fc.jpg', 'Manis Gurih\r\n			', 10000),
('P0006', 'angel food cake', '65af2e9d74fdb.jpg', '\r\n			', 10000),
('P0007', 'Bisquit Cake', '65af2ec03a468.jpg', '\r\n			', 20000);

-- --------------------------------------------------------

--
-- Table structure for table `produksi`
--

CREATE TABLE `produksi` (
  `id_order` int(11) NOT NULL,
  `invoice` varchar(200) NOT NULL,
  `kode_customer` varchar(200) NOT NULL,
  `kode_produk` varchar(200) NOT NULL,
  `nama_produk` varchar(200) NOT NULL,
  `qty` int(11) NOT NULL,
  `harga` int(11) NOT NULL,
  `status` varchar(200) NOT NULL,
  `tanggal` date NOT NULL,
  `provinsi` varchar(200) NOT NULL,
  `kota` varchar(200) NOT NULL,
  `alamat` varchar(200) NOT NULL,
  `kode_pos` varchar(200) NOT NULL,
  `terima` varchar(200) NOT NULL,
  `tolak` varchar(200) NOT NULL,
  `cek` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `produksi`
--

INSERT INTO `produksi` (`id_order`, `invoice`, `kode_customer`, `kode_produk`, `nama_produk`, `qty`, `harga`, `status`, `tanggal`, `provinsi`, `kota`, `alamat`, `kode_pos`, `terima`, `tolak`, `cek`) VALUES
(8, 'INV0001', 'C0002', 'P0003', 'Kue tart coklat', 1, 100000, 'Pesanan Baru', '2020-07-27', 'Jawa Timur', 'Surabaya', 'Jl.Tanah Merah Indah 1', '60129', '2', '1', 0),
(9, 'INV0002', 'C0002', 'P0001', 'Roti Sobek', 3, 10000, 'Pesanan Baru', '2020-07-27', 'Jawa Barat', 'Bandung', 'Jl.Jati Nangor Blok C, 10', '30712', '2', '1', 0),
(10, 'INV0003', 'C0003', 'P0002', 'Maryam', 2, 15000, '0', '2020-07-27', 'Jawa Tengah', 'Yogyakarta', 'Jl.Malioboro, Blok A 10D', '30123', '1', '0', 0),
(11, 'INV0003', 'C0003', 'P0003', 'Kue tart coklat', 1, 100000, '0', '2020-07-27', 'Jawa Tengah', 'Yogyakarta', 'Jl.Malioboro, Blok A 10D', '30123', '1', '0', 0),
(12, 'INV0003', 'C0003', 'P0001', 'Roti Sobek', 1, 10000, '0', '2020-07-27', 'Jawa Tengah', 'Yogyakarta', 'Jl.Malioboro, Blok A 10D', '30123', '1', '0', 0),
(13, 'INV0004', 'C0004', 'P0002', 'Maryam', 1, 15000, '0', '2020-07-26', 'Jawa Timur', 'Sidoarjo', 'Jl.KH Syukur Blok C 18 A', '50987', '1', '0', 0),
(14, 'INV0005', 'C0005', 'P0001', 'Roti Sobek', 1, 10000, '0', '2323-07-15', 'Jawa Barat', 'Bandung', 'Ujung Berung', '40397', '1', '0', 0),
(15, 'INV0006', 'C0006', 'P0003', 'Kue tart coklat', 10, 100000, '0', '2424-01-11', 'jawa tengah', 'jepara', 'ngasem', '123', '1', '0', 0),
(16, 'INV0006', 'C0006', 'P0001', 'Roti Sobek', 10, 10000, '0', '2424-01-11', 'jawa tengah', 'jepara', 'ngasem', '123', '1', '0', 0),
(17, 'INV0007', 'C0006', 'P0001', 'Roti Sobek', 1, 10000, '0', '2424-01-14', 'jawa tengah', 'jepara', 'ngasem', '123', '1', '0', 0),
(18, 'INV0007', 'C0006', 'P0002', 'Maryam', 1, 15000, '0', '2424-01-14', 'jawa tengah', 'jepara', 'ngasem', '123', '1', '0', 0),
(19, 'INV0008', 'C0006', 'P0002', 'Maryam', 1, 15000, '0', '2424-01-14', '', '', '', '', '1', '0', 0),
(20, 'INV0009', 'C0007', 'P0002', 'Caramel', 2, 35000, '0', '2424-01-20', 'jawa tengah', 'jepara', 'ngasem', '12345678', '1', '0', 0),
(21, 'INV0009', 'C0007', 'P0003', 'Bolu Band', 2, 25000, '0', '2424-01-20', 'jawa tengah', 'jepara', 'ngasem', '12345678', '1', '0', 0),
(22, 'INV0010', 'C0003', 'P0002', 'Maryam', 6, 15000, 'Pesanan Baru', '2424-01-24', 'jawa tengah', 'jepara', 'ngasem', '123', '0', '0', 0),
(23, 'INV0010', 'C0003', 'P0003', 'Kue tart coklat', 2, 100000, 'Pesanan Baru', '2424-01-24', 'jawa tengah', 'jepara', 'ngasem', '123', '0', '0', 0);

-- --------------------------------------------------------

--
-- Table structure for table `report_cancel`
--

CREATE TABLE `report_cancel` (
  `id_report_cancel` int(11) NOT NULL,
  `id_order` varchar(100) NOT NULL,
  `kode_produk` varchar(100) NOT NULL,
  `jumlah` varchar(100) NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `report_inventory`
--

CREATE TABLE `report_inventory` (
  `id_report_inv` int(11) NOT NULL,
  `kode_bk` varchar(100) NOT NULL,
  `nama_bahanbaku` varchar(100) NOT NULL,
  `jml_stok_bk` int(11) NOT NULL,
  `tanggal` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `report_omset`
--

CREATE TABLE `report_omset` (
  `id_report_omset` int(11) NOT NULL,
  `invoice` varchar(100) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `total_omset` int(11) NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `report _penjualan`
--

CREATE TABLE `report _penjualan` (
  `id_report_sell` int(11) NOT NULL,
  `invoice` varchar(100) NOT NULL,
  `kode_produk` varchar(100) NOT NULL,
  `nama_produk` varchar(100) NOT NULL,
  `jumlah_terjual` int(11) NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `report_produksi`
--

CREATE TABLE `report_produksi` (
  `id_report_prd` int(11) NOT NULL,
  `invoice` varchar(100) NOT NULL,
  `kode_produk` varchar(100) NOT NULL,
  `nama_produk` varchar(100) NOT NULL,
  `qty` int(11) NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `report_profit`
--

CREATE TABLE `report_profit` (
  `id_report_profit` int(11) NOT NULL,
  `kode_bom` varchar(100) NOT NULL,
  `invoice` varchar(100) NOT NULL,
  `kode_produk` varchar(100) NOT NULL,
  `jumlah` varchar(11) NOT NULL,
  `total_profit` varchar(11) NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`kode_customer`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`kode_bk`);

--
-- Indexes for table `keranjang`
--
ALTER TABLE `keranjang`
  ADD PRIMARY KEY (`id_keranjang`);

--
-- Indexes for table `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`kode_produk`);

--
-- Indexes for table `produksi`
--
ALTER TABLE `produksi`
  ADD PRIMARY KEY (`id_order`);

--
-- Indexes for table `report_cancel`
--
ALTER TABLE `report_cancel`
  ADD PRIMARY KEY (`id_report_cancel`);

--
-- Indexes for table `report_inventory`
--
ALTER TABLE `report_inventory`
  ADD PRIMARY KEY (`id_report_inv`);

--
-- Indexes for table `report_omset`
--
ALTER TABLE `report_omset`
  ADD PRIMARY KEY (`id_report_omset`);

--
-- Indexes for table `report _penjualan`
--
ALTER TABLE `report _penjualan`
  ADD PRIMARY KEY (`id_report_sell`);

--
-- Indexes for table `report_produksi`
--
ALTER TABLE `report_produksi`
  ADD PRIMARY KEY (`id_report_prd`);

--
-- Indexes for table `report_profit`
--
ALTER TABLE `report_profit`
  ADD PRIMARY KEY (`id_report_profit`),
  ADD UNIQUE KEY `kode_bom` (`kode_bom`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `keranjang`
--
ALTER TABLE `keranjang`
  MODIFY `id_keranjang` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `produksi`
--
ALTER TABLE `produksi`
  MODIFY `id_order` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `report_cancel`
--
ALTER TABLE `report_cancel`
  MODIFY `id_report_cancel` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `report_inventory`
--
ALTER TABLE `report_inventory`
  MODIFY `id_report_inv` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `report_omset`
--
ALTER TABLE `report_omset`
  MODIFY `id_report_omset` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `report _penjualan`
--
ALTER TABLE `report _penjualan`
  MODIFY `id_report_sell` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `report_produksi`
--
ALTER TABLE `report_produksi`
  MODIFY `id_report_prd` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `report_profit`
--
ALTER TABLE `report_profit`
  MODIFY `id_report_profit` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
