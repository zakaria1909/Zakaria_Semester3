<?php
include 'header.php';
?>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<meta name="description" content="">
<meta name="author" content="">
<link rel="icon" href="homepage.png">
<title>Home</title>
<!-- Bootstrap core CSS -->
<link href="css/bootstrap.min.css" rel="stylesheet">
<!-- Template Stylesheet -->
<link href="css/style.css" rel="stylesheet">
	<!-- IMAGE -->
	<div class="container-fluid" style="margin: 0;padding: 0;">
	<div class="image" style="margin-top: -21px">
		<img src="image/home/bgcake.jpg" style="width: 100%;  height: 650px;">
	</div>
</div>
	<br>
	<br>
	<br>
<body style="">
	<!-- PRODUK TERBARU -->
	<div class="container ">
		<div class="row">
			<div class="col-lg-6">
				<img src="image/home/koki.jpg" class="img-thumbnail" alt="" style="width:800px;">
			</div>
			<div class="col-lg-6">
				<h4 style="margin-left:10px;">Ahza Cake & Bakery sudah berdiri sejak 12 tahun lalu, berawal dari usaha rumahan kecil-kecilan sekarang sudah ada 6 toko yang berada di Jepara dan Kudus. Kami merupakan produsen cake yang halal dengan bahan berkualitas dan terjangkau untuk semua kalangan. Produk kami terdiri dari berbagai macam cake tart, produk oleh-oleh, roti gurih dan kue kering.</h4>
			</div>
		</div>
	</div>
	<!-- <div class="container" style="">
	<div class="gamteks" style="display: flex; font-family: arial; padding-top: 10px; padding-bottom: 10px; font-style: italic; line-height: 29px;">
	<div class="gam">
	<img src="image/home/koki.jpg" class="img-thumbnail" alt="" style="width:800px;">
	</div>
	<div class="teks">
		<h4 style="margin-left:10px;">Ahza Cake & Bakery adalah salah satu pelopor pertama dalam bisnis roti modern di Indonesia. Didirikan pada tahun 1978,  saat ini dikelola di bawah PT. Mustika Citra Rasa. Produk kami sehat, bergizi, dan terjangkau oleh semua orang.</h4></div>
		</div>
</div> -->
	<div class="produks" style="background-image: url(image/home/footer_pattern.png);">
		<h2 style=" width: 100%;  margin-top: 80px; text-align: center; color:grey;"><b>Produk Kami</b></h2>
		<div class="container" style="justify-content: center; width:99%;">
			<?php
			$result = mysqli_query($conn, "SELECT * FROM produk");
			while ($row = mysqli_fetch_assoc($result)) {
				?>
				<div class="col-sm-6 col-md-2" >
					<div class="thumbnail"style="background-color:#A6A6A6;">
						<img src="image/produk/<?= $row['image']; ?>">
						<div class="caption">
							<h3><b>
									<?= $row['nama']; ?>
								</b></h3>
							<!-- <hr > -->
							<h4>Rp.
								<?= number_format($row['harga']); ?>
							</h4>
							<!-- <hr> -->
							<div class="row">
								<div class="col-md-5">
									<a href="detail_produk.php?produk=<?= $row['kode_produk']; ?>"
										class="btn btn-warning btn-block"
										style="border-radius: 15px 15px 15px 15px;">Detail</a>
								</div>
								<?php if (isset($_SESSION['kd_cs'])) { ?>
									<div class="col-md-5 ">
										<a href="proses/add.php?produk=<?= $row['kode_produk']; ?>&kd_cs=<?= $kode_cs; ?>&hal=1"
											class="btn btn-success btn-block" role="button"
											style="border-radius: 15px 15px 15px 15px;"><i
												class="glyphicon glyphicon-shopping-cart"></i></a>
									</div>
									<?php
								} else {
									?>
									<div class="col-md-5">
										<a href="keranjang.php" class="btn btn-success btn-block" role="button" style="border-radius: 15px 15px 15px 15px;"><i
												class="glyphicon glyphicon-shopping-cart"></i></a>
									</div>

									<?php
								}
								?>

							</div>

						</div>
					</div>
				</div>
				<?php
			}
			?>
		</div>
	</div>
	<h2 style="text-align:center;"><b>MASTER CHEF</b></h2>
	<div class="container text-center">
		<div class="row" style="display:flex; gap:30px;">
			<div class="col">
				<img src="image/home/team-1.jpg" class="img-thumbnail" alt="" style="">
				<h3>reza</h3>
			</div>
			<div class="col">
				<img src="image/home/team-1.jpg" class="img-thumbnail" alt="" style="">
				<h3>reza</h3>
			</div>
			<div class="col">
				<img src="image/home/team-1.jpg" class="img-thumbnail" alt="" style="">
				<h3>reza</h3>
			</div>
		</div>
	</div>
	<br>

</body>
<?php
include 'footer.php';
?>