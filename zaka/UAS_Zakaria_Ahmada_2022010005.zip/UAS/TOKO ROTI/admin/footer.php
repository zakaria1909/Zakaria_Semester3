<footer style="background-color: gray;padding: 1px;" class="print">
	<h5 class="text-center">Copyright&copy; Zakaria Ahmada</h5>
</footer>
</body>
</html>